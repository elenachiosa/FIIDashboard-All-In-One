# Introduction
FIIDashboard - web app for students (UI/Front-end only) to visualize their educational trajectory (grades, attendance etc.).
 
# Getting Started
## Frontend
- inside the folder that contains angular-cli.json, run `npm install`
- after node_modules folder is created, run `ng serve -o` to start the app in development mode and open the app in your default browser
