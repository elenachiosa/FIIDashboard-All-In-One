import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'fd-taxes',
  templateUrl: './taxes.component.html',
  styleUrls: ['./taxes.component.scss']
})
export class TaxesComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
