import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'fd-trajectory',
  templateUrl: './trajectory.component.html',
  styleUrls: ['./trajectory.component.scss']
})
export class TrajectoryComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
