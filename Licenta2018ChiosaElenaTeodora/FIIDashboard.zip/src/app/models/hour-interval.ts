export class HourInterval {
  start: number;
  end: number;
}
