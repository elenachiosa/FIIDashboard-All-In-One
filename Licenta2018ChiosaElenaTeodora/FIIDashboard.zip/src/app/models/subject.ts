export class Subject {
  title: string;
  shortTitle: string;
  color: string;
  course: string;
  seminar: string;
  teachers: string[];
  optional: boolean;
  description: string;
}
