export class WeekDay {
  name: string;
  shortName: string;
}
